
import { GoogleGenAI } from "@google/genai";
import { PlacementRecord } from "../types";

// IMPORTANT: This check is to prevent crashing in environments where process.env is not defined.
const apiKey = typeof process !== 'undefined' && process.env && process.env.API_KEY
  ? process.env.API_KEY
  : "";

if (!apiKey) {
    console.warn("API_KEY environment variable not set. AI Assistant will not work.");
}

const ai = new GoogleGenAI({ apiKey });

export const analyzePlacements = async (question: string, data: PlacementRecord[]): Promise<string> => {
    if (!apiKey) {
        return "API key is not configured. The AI assistant is disabled.";
    }
    
    if (data.length === 0) {
        return "There is no data to analyze. Please select one or more IITs to view their data and ask questions.";
    }

    const model = 'gemini-2.5-flash';
    
    const dataSummary = data.map(d => 
        `IIT: ${d.iitName}, Year: ${d.year}, Avg Pkg (LPA): ${d.averagePackageLPA}, High Pkg (LPA): ${d.highestPackageLPA}, Placement %: ${d.placementPercentage}`
    ).join('\n');

    const systemInstruction = `You are a helpful data analyst specializing in Indian Institute of Technology (IIT) placement statistics. 
    Your role is to answer questions based *only* on the provided data. 
    - Do not use any external knowledge or make assumptions beyond the data.
    - Provide concise, data-driven answers.
    - If the data is insufficient to answer the question, state that clearly.
    - Present your answer in a clear, readable format. You can use markdown for formatting if needed.`;

    const contents = `DATA:
---
${dataSummary}
---

QUESTION:
${question}`;

    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: contents,
            config: {
                systemInstruction: systemInstruction,
                temperature: 0.2,
                topP: 0.9,
                topK: 32,
            }
        });

        return response.text;
    } catch (error) {
        console.error("Error calling Gemini API:", error);
        throw new Error("Failed to communicate with the AI model.");
    }
};
