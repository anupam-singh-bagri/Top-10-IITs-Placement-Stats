
import React, { useState } from 'react';
import { ALL_IITS, METRICS, CHART_TYPES } from '../constants';
import { IITName, Metric, ChartType } from '../types';
import { ChevronDownIcon, ChevronUpIcon } from './icons';

interface ControlPanelProps {
    selectedIITs: IITName[];
    onIITsChange: (iits: IITName[]) => void;
    selectedMetric: Metric;
    onMetricChange: (metric: Metric) => void;
    selectedChartType: ChartType;
    onChartTypeChange: (type: ChartType) => void;
}

const ControlPanel: React.FC<ControlPanelProps> = ({
    selectedIITs,
    onIITsChange,
    selectedMetric,
    onMetricChange,
    selectedChartType,
    onChartTypeChange,
}) => {
    const [isIitDropdownOpen, setIitDropdownOpen] = useState(false);

    const handleIitSelection = (iit: IITName) => {
        const newSelection = selectedIITs.includes(iit)
            ? selectedIITs.filter(name => name !== iit)
            : [...selectedIITs, iit];
        onIITsChange(newSelection);
    };
    
    const toggleSelectAll = () => {
        if(selectedIITs.length === ALL_IITS.length) {
            onIITsChange([]);
        } else {
            onIITsChange([...ALL_IITS]);
        }
    }

    return (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* IITs Selector */}
            <div className="relative">
                <label className="block text-sm font-medium text-text-secondary mb-1">Select IITs</label>
                <button
                    onClick={() => setIitDropdownOpen(!isIitDropdownOpen)}
                    className="w-full bg-background border border-border-color rounded-md shadow-sm pl-3 pr-10 py-2 text-left focus:outline-none focus:ring-1 focus:ring-accent focus:border-accent flex justify-between items-center"
                >
                    <span className="truncate">{selectedIITs.length} IITs selected</span>
                    {isIitDropdownOpen ? <ChevronUpIcon className="w-5 h-5" /> : <ChevronDownIcon className="w-5 h-5" />}
                </button>
                {isIitDropdownOpen && (
                    <div className="absolute z-10 mt-1 w-full bg-surface border border-border-color rounded-md shadow-lg max-h-60 overflow-auto">
                        <div className="p-2">
                           <button onClick={toggleSelectAll} className="w-full text-left px-2 py-1.5 text-sm rounded hover:bg-background">{selectedIITs.length === ALL_IITS.length ? 'Deselect All' : 'Select All'}</button>
                        </div>
                        <hr className="border-border-color" />
                        <ul className="py-1">
                            {ALL_IITS.map(iit => (
                                <li key={iit} className="flex items-center px-3 py-2 cursor-pointer hover:bg-background" onClick={() => handleIitSelection(iit)}>
                                    <input
                                        type="checkbox"
                                        checked={selectedIITs.includes(iit)}
                                        readOnly
                                        className="h-4 w-4 rounded border-gray-300 text-accent focus:ring-accent"
                                    />
                                    <span className="ml-3 text-sm text-text-primary">{iit}</span>
                                </li>
                            ))}
                        </ul>
                    </div>
                )}
            </div>

            {/* Metric Selector */}
            <div>
                <label htmlFor="metric-select" className="block text-sm font-medium text-text-secondary mb-1">Select Metric</label>
                <select
                    id="metric-select"
                    value={selectedMetric}
                    onChange={e => onMetricChange(e.target.value as Metric)}
                    className="w-full bg-background border border-border-color rounded-md shadow-sm pl-3 pr-10 py-2 text-left focus:outline-none focus:ring-1 focus:ring-accent focus:border-accent"
                >
                    {METRICS.map(metric => <option key={metric}>{metric}</option>)}
                </select>
            </div>

            {/* Chart Type Selector */}
            <div>
                <label htmlFor="chart-type-select" className="block text-sm font-medium text-text-secondary mb-1">Select Chart Type</label>
                <select
                    id="chart-type-select"
                    value={selectedChartType}
                    onChange={e => onChartTypeChange(e.target.value as ChartType)}
                    className="w-full bg-background border border-border-color rounded-md shadow-sm pl-3 pr-10 py-2 text-left focus:outline-none focus:ring-1 focus:ring-accent focus:border-accent"
                >
                    {CHART_TYPES.map(type => <option key={type}>{type}</option>)}
                </select>
            </div>
        </div>
    );
};

export default ControlPanel;
