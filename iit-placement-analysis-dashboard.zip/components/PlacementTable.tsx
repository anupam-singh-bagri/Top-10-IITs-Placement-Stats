
import React, { useState, useMemo } from 'react';
import { PlacementRecord } from '../types';
import { ArrowUpIcon, ArrowDownIcon } from './icons';

interface PlacementTableProps {
    data: PlacementRecord[];
}

type SortKey = keyof PlacementRecord;
type SortOrder = 'asc' | 'desc';

const PlacementTable: React.FC<PlacementTableProps> = ({ data }) => {
    const [sortConfig, setSortConfig] = useState<{ key: SortKey; order: SortOrder } | null>({ key: 'iitName', order: 'asc'});

    const sortedData = useMemo(() => {
        let sortableData = [...data];
        if (sortConfig !== null) {
            sortableData.sort((a, b) => {
                if (a[sortConfig.key] < b[sortConfig.key]) {
                    return sortConfig.order === 'asc' ? -1 : 1;
                }
                if (a[sortConfig.key] > b[sortConfig.key]) {
                    return sortConfig.order === 'asc' ? 1 : -1;
                }
                return 0;
            });
        }
        return sortableData;
    }, [data, sortConfig]);

    const requestSort = (key: SortKey) => {
        let order: SortOrder = 'asc';
        if (sortConfig && sortConfig.key === key && sortConfig.order === 'asc') {
            order = 'desc';
        }
        setSortConfig({ key, order });
    };
    
    const getSortIcon = (key: SortKey) => {
        if (!sortConfig || sortConfig.key !== key) {
            return null;
        }
        return sortConfig.order === 'asc' ? <ArrowUpIcon className="w-4 h-4 inline ml-1" /> : <ArrowDownIcon className="w-4 h-4 inline ml-1" />;
    };

    const headers: { key: SortKey; label: string }[] = [
        { key: 'iitName', label: 'IIT Name' },
        { key: 'year', label: 'Year' },
        { key: 'averagePackageLPA', label: 'Average Package (LPA)' },
        { key: 'highestPackageLPA', label: 'Highest Package (LPA)' },
        { key: 'placementPercentage', label: 'Placement %' },
    ];
    
    if (data.length === 0) {
        return <p className="text-text-secondary">No data to display in table. Please select at least one IIT.</p>;
    }

    return (
        <div>
            <h3 className="text-lg font-semibold text-text-primary mb-4">Placement Data Details</h3>
            <div className="overflow-x-auto max-h-[400px]">
                <table className="min-w-full divide-y divide-border-color">
                    <thead className="bg-background sticky top-0">
                        <tr>
                            {headers.map(({ key, label }) => (
                                <th
                                    key={key}
                                    scope="col"
                                    className="px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider cursor-pointer"
                                    onClick={() => requestSort(key)}
                                >
                                    {label}
                                    {getSortIcon(key)}
                                </th>
                            ))}
                        </tr>
                    </thead>
                    <tbody className="bg-surface divide-y divide-border-color">
                        {sortedData.map((record, index) => (
                            <tr key={`${record.iitName}-${record.year}-${index}`} className="hover:bg-background">
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-text-primary">{record.iitName}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary">{record.year}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary">{record.averagePackageLPA.toFixed(2)}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary">{record.highestPackageLPA.toFixed(2)}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-text-secondary">{record.placementPercentage.toFixed(2)}%</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default PlacementTable;
