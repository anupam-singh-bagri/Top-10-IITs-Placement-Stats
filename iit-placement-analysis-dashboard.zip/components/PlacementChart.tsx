
import React, { useMemo } from 'react';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { PlacementRecord, Metric, ChartType } from '../types';
import { METRICS_MAP, YEARS, CHART_COLORS } from '../constants';

interface PlacementChartProps {
    data: PlacementRecord[];
    metric: Metric;
    chartType: ChartType;
}

const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
        return (
            <div className="bg-surface p-2 border border-border-color rounded-md shadow-lg">
                <p className="label font-bold text-text-primary">{`${label}`}</p>
                {payload.map((p: any) => (
                    <p key={p.name} style={{ color: p.color }} className="intro text-sm">{`${p.name} : ${p.value.toFixed(2)}`}</p>
                ))}
            </div>
        );
    }
    return null;
};


const PlacementChart: React.FC<PlacementChartProps> = ({ data, metric, chartType }) => {
    const metricInfo = METRICS_MAP[metric];

    const chartData = useMemo(() => {
        return YEARS.map(year => {
            const yearData: { [key: string]: string | number } = { name: String(year) };
            data.forEach(record => {
                if (record.year === year) {
                    yearData[record.iitName] = record[metricInfo.key];
                }
            });
            return yearData;
        });
    }, [data, metricInfo.key]);

    const iitsInView = useMemo(() => {
        return [...new Set(data.map(d => d.iitName))];
    }, [data]);
    
    if (data.length === 0) {
        return (
            <div className="flex items-center justify-center h-full">
                <p className="text-text-secondary">Please select at least one IIT to display data.</p>
            </div>
        );
    }


    const renderChart = () => {
        if (chartType === 'Bar Chart') {
            return (
                <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke={METRICS_MAP['border-color']} />
                    <XAxis dataKey="name" stroke={'#D1D5DB'} />
                    <YAxis stroke={'#D1D5DB'} unit={metricInfo.unit} />
                    <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(107, 114, 128, 0.1)' }} />
                    <Legend wrapperStyle={{ color: '#D1D5DB' }} />
                    {iitsInView.map((iit, index) => (
                        <Bar key={iit} dataKey={iit} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                    ))}
                </BarChart>
            );
        } else {
            return (
                <LineChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke={METRICS_MAP['border-color']} />
                    <XAxis dataKey="name" stroke={'#D1D5DB'} />
                    <YAxis stroke={'#D1D5DB'} unit={metricInfo.unit} />
                    <Tooltip content={<CustomTooltip />} cursor={{ stroke: 'rgba(107, 114, 128, 0.5)', strokeWidth: 1 }} />
                    <Legend wrapperStyle={{ color: '#D1D5DB' }} />
                    {iitsInView.map((iit, index) => (
                        <Line key={iit} type="monotone" dataKey={iit} stroke={CHART_COLORS[index % CHART_COLORS.length]} strokeWidth={2} activeDot={{ r: 8 }} />
                    ))}
                </LineChart>
            );
        }
    };

    return (
        <>
            <h3 className="text-lg font-semibold text-text-primary mb-4">{`${metric} Trends (${chartType})`}</h3>
            <ResponsiveContainer width="100%" height={350}>
                {renderChart()}
            </ResponsiveContainer>
        </>
    );
};

export default PlacementChart;
