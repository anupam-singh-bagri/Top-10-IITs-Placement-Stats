
import React, { useState } from 'react';
import { analyzePlacements } from '../services/geminiService';
import { PlacementRecord } from '../types';
import { SendIcon, LoadingIcon, SparklesIcon } from './icons';

interface AIAssistantProps {
    data: PlacementRecord[];
}

const AIAssistant: React.FC<AIAssistantProps> = ({ data }) => {
    const [query, setQuery] = useState('');
    const [response, setResponse] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState('');

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!query.trim()) return;

        setIsLoading(true);
        setError('');
        setResponse('');

        try {
            const result = await analyzePlacements(query, data);
            setResponse(result);
        } catch (err) {
            setError('Failed to get analysis. Please check your API key or try again later.');
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };

    const exampleQueries = [
        "Which IIT had the highest average package in 2024?",
        "Compare the placement percentage growth for IIT Bombay and IIT Delhi from 2020 to 2024.",
        "What is the overall trend for highest packages across all selected IITs?",
    ];

    return (
        <div className="flex flex-col h-full">
            <h3 className="text-lg font-semibold text-text-primary mb-2 flex items-center">
                <SparklesIcon className="w-5 h-5 mr-2 text-accent" />
                AI Placement Analyst
            </h3>
            <p className="text-sm text-text-secondary mb-4">Ask a question about the selected data.</p>
            
            <div className="flex-grow bg-background rounded-lg p-4 mb-4 overflow-y-auto min-h-[150px]">
                {isLoading ? (
                    <div className="flex items-center justify-center h-full">
                        <LoadingIcon className="w-8 h-8 animate-spin text-accent" />
                    </div>
                ) : error ? (
                    <p className="text-red-400">{error}</p>
                ) : response ? (
                    <p className="whitespace-pre-wrap text-text-primary text-sm">{response}</p>
                ) : (
                    <div className="text-text-secondary text-sm">
                        <p className="font-semibold mb-2">Example questions:</p>
                        <ul className="list-disc list-inside space-y-1">
                            {exampleQueries.map(q => <li key={q}>{q}</li>)}
                        </ul>
                    </div>
                )}
            </div>

            <form onSubmit={handleSubmit} className="flex space-x-2">
                <input
                    type="text"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="e.g., Highest average package in 2024?"
                    className="flex-grow bg-gray-800 border border-border-color rounded-md px-3 py-2 focus:outline-none focus:ring-1 focus:ring-accent focus:border-accent text-sm"
                    disabled={isLoading}
                />
                <button
                    type="submit"
                    className="bg-accent text-white rounded-md px-4 py-2 flex items-center justify-center hover:bg-brand-secondary disabled:bg-gray-500 disabled:cursor-not-allowed"
                    disabled={isLoading || !query.trim()}
                >
                    {isLoading ? <LoadingIcon className="w-5 h-5 animate-spin" /> : <SendIcon className="w-5 h-5" />}
                </button>
            </form>
        </div>
    );
};

export default AIAssistant;
