
import React from 'react';
import { GraduationCapIcon } from './icons';

const Header: React.FC = () => {
    return (
        <header className="flex items-center justify-center sm:justify-start space-x-4 text-center sm:text-left p-4 bg-surface rounded-xl border border-border-color shadow-lg">
            <GraduationCapIcon className="w-10 h-10 sm:w-12 sm:h-12 text-accent" />
            <div>
                <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-text-primary tracking-tight">
                    IIT Placement Analysis
                </h1>
                <p className="text-sm sm:text-md text-text-secondary">Dashboard for 2020-2024</p>
            </div>
        </header>
    );
};

export default Header;
