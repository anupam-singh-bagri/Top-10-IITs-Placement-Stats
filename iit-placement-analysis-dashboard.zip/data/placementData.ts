
import { ALL_IITS, YEARS } from '../constants';
import { PlacementRecord, IITName } from '../types';

const BASE_STATS: Record<IITName, { avg: number; high: number; perc: number }> = {
    'IIT Bombay': { avg: 22, high: 150, perc: 90 },
    'IIT Delhi': { avg: 21, high: 145, perc: 89 },
    'IIT Madras': { avg: 20, high: 130, perc: 88 },
    'IIT Kanpur': { avg: 19, high: 125, perc: 87 },
    'IIT Kharagpur': { avg: 18, high: 120, perc: 86 },
    'IIT Roorkee': { avg: 17, high: 110, perc: 85 },
    'IIT Guwahati': { avg: 16, high: 100, perc: 84 },
    'IIT Hyderabad': { avg: 17.5, high: 90, perc: 88 },
    'IIT (BHU) Varanasi': { avg: 15, high: 85, perc: 82 },
    'IIT Gandhinagar': { avg: 14, high: 75, perc: 80 },
    'IIT Ropar': { avg: 13.5, high: 70, perc: 78 },
    'IIT Patna': { avg: 13, high: 65, perc: 77 },
    'IIT Jodhpur': { avg: 12.5, high: 60, perc: 76 },
    'IIT Indore': { avg: 14.5, high: 80, perc: 81 },
    'IIT Mandi': { avg: 12, high: 55, perc: 75 },
};

const annualGrowth = {
    avg: 1.08, // 8% average growth
    high: 1.12, // 12% highest growth
    perc: 1.005, // 0.5% placement growth
};

export const generatePlacementData = (): PlacementRecord[] => {
    const data: PlacementRecord[] = [];

    ALL_IITS.forEach(iit => {
        let currentAvg = BASE_STATS[iit].avg;
        let currentHigh = BASE_STATS[iit].high;
        let currentPerc = BASE_STATS[iit].perc;

        YEARS.forEach(year => {
            // Add some randomness to make it look real
            const randomFactor = 1 + (Math.random() - 0.5) * 0.1; // +/- 5% variance

            currentAvg *= annualGrowth.avg * randomFactor;
            currentHigh *= annualGrowth.high * randomFactor;
            currentPerc = Math.min(99, currentPerc * annualGrowth.perc);

            data.push({
                iitName: iit,
                year: year,
                averagePackageLPA: parseFloat(currentAvg.toFixed(2)),
                highestPackageLPA: parseFloat(currentHigh.toFixed(2)),
                placementPercentage: parseFloat(currentPerc.toFixed(2)),
            });
        });
    });

    return data;
};
